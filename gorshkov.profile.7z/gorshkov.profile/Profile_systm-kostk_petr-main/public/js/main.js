document.addEventListener('DOMContentLoaded', function() {
    const avatarImg = document.getElementById('avatar-img');
    const userName = document.getElementById('user-name');
    const userEmail = document.getElementById('user-email');
    const editForm = document.getElementById('edit-form');
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const avatarInput = document.getElementById('avatar-input');
    const deleteAvatarBtn = document.getElementById('delete-avatar-btn');
    const resetBtn = document.getElementById('reset-btn');
    const messageModal = document.getElementById('message-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalMessage = document.getElementById('modal-message');
    const modalClose = document.querySelector('.modal-close');
    const modalOk = document.getElementById('modal-ok');
    
    let currentUser = null;
 
    async function loadUserData() {
        try {
            const response = await fetch('/api/user');
            if (response.ok) {
                currentUser = await response.json();
                updateUI();
            } else {
                showModal('Ошибка', 'Не удалось загрузить данные пользователя');
            }
        } catch (error) {
            showModal('Ошибка', 'Ошибка соединения с сервером');
        }
    }

    function updateUI() {
        if (!currentUser) return;
        
        userName.textContent = currentUser.name;
        userEmail.textContent = currentUser.email;
        nameInput.value = currentUser.name;
        emailInput.value = currentUser.email;

        if (currentUser.avatar) {
            avatarImg.src = `/uploads/avatars/${currentUser.avatar}?t=${Date.now()}`;
        }
    }
 
    avatarInput.addEventListener('change', async function(e) {
        const file = e.target.files[0];
        if (!file) return;
        
        if (file.size > 5 * 1024 * 1024) {
            showModal('Ошибка', 'Файл слишком большой. Максимальный размер: 5MB');
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            avatarImg.src = e.target.result;
        };
        reader.readAsDataURL(file);
        
        const formData = new FormData();
        formData.append('avatar', file);
        
        try {
            const response = await fetch('/api/user/avatar', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (response.ok) {
                currentUser.avatar = result.avatar;
                showModal('Успех', 'Аватар успешно обновлен!');
            } else {
                showModal('Ошибка', result.error || 'Ошибка при загрузке аватара');
                loadUserData();
            }
        } catch (error) {
            showModal('Ошибка', 'Ошибка соединения с сервером');
            loadUserData();
        }
       
        avatarInput.value = '';
    });
    
    deleteAvatarBtn.addEventListener('click', async function() {
        if (!confirm('Удалить текущий аватар?')) return;
        
        try {
            const response = await fetch('/api/user/avatar', {
                method: 'DELETE'
            });
            
            const result = await response.json();
            
            if (response.ok) {
                currentUser.avatar = 'default-avatar.png';
                avatarImg.src = '/uploads/avatars/default-avatar.png';
                showModal('Успех', 'Аватар удален');
            } else {
                showModal('Ошибка', result.error || 'Ошибка при удалении аватара');
            }
        } catch (error) {
            showModal('Ошибка', 'Ошибка соединения с сервером');
        }
    });
    
    editForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const password = passwordInput.value.trim();
        if (!password) {
            showModal('Ошибка', 'Введите текущий пароль для подтверждения');
            return;
        }
        
        try {
            const checkResponse = await fetch('/api/user/check-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ password })
            });
            
            const checkResult = await checkResponse.json();
            
            if (!checkResult.valid) {
                showModal('Ошибка', checkResult.error || 'Неверный пароль');
                return;
            }
            
            const updateData = {
                name: nameInput.value.trim(),
                email: emailInput.value.trim()
            };
            
            const updateResponse = await fetch('/api/user', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(updateData)
            });
            
            const updateResult = await updateResponse.json();
            
            if (updateResponse.ok) {
                currentUser = updateResult.user;
                updateUI();
                passwordInput.value = '';
                showModal('Успех', 'Данные успешно обновлены!');
            } else {
                showModal('Ошибка', updateResult.error || 'Ошибка при обновлении данных');
            }
        } catch (error) {
            showModal('Ошибка', 'Ошибка соединения с сервером');
        }
    });

    resetBtn.addEventListener('click', function() {
        if (confirm('Сбросить все изменения?')) {
            updateUI();
            passwordInput.value = '';
        }
    });
    
    function showModal(title, message) {
        modalTitle.textContent = title;
        modalMessage.textContent = message;
        messageModal.classList.add('show');
    }
    
    function hideModal() {
        messageModal.classList.remove('show');
    }
    
    modalClose.addEventListener('click', hideModal);
    modalOk.addEventListener('click', hideModal);
    
    messageModal.addEventListener('click', function(e) {
        if (e.target === messageModal) {
            hideModal();
        }
    });
   
    loadUserData();
    
    addGeometricDecorations();
});

function addGeometricDecorations() {
    const colors = ['#4361ee', '#7209b7', '#4cc9f0', '#f72585'];
    const shapes = ['circle', 'triangle', 'square', 'hexagon'];
    
    for (let i = 0; i < 15; i++) {
        const shape = document.createElement('div');
        const size = Math.random() * 40 + 20;
        const color = colors[Math.floor(Math.random() * colors.length)];
        const shapeType = shapes[Math.floor(Math.random() * shapes.length)];
        
        shape.style.position = 'fixed';
        shape.style.width = size + 'px';
        shape.style.height = size + 'px';
        shape.style.opacity = '0.03';
        shape.style.zIndex = '-1';
        shape.style.pointerEvents = 'none';
        shape.style.left = Math.random() * 100 + 'vw';
        shape.style.top = Math.random() * 100 + 'vh';
        shape.style.animation = `float ${Math.random() * 10 + 10}s ease-in-out infinite`;
        shape.style.animationDelay = Math.random() * 5 + 's';
        
        switch(shapeType) {
            case 'circle':
                shape.style.borderRadius = '50%';
                shape.style.background = color;
                break;
            case 'triangle':
                shape.style.background = 'transparent';
                shape.style.borderBottom = `${size}px solid ${color}`;
                shape.style.borderLeft = `${size/2}px solid transparent`;
                shape.style.borderRight = `${size/2}px solid transparent`;
                shape.style.width = '0';
                shape.style.height = '0';
                break;
            case 'square':
                shape.style.transform = 'rotate(45deg)';
                shape.style.background = color;
                break;
            case 'hexagon':
                shape.style.background = color;
                shape.style.clipPath = 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)';
                break;
        }
        
        document.body.appendChild(shape);
    }
}