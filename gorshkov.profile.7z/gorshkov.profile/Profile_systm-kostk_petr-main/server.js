const express = require('express');
const multer = require('multer');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.static(path.join(__dirname, 'public')));

let users = [];
const USERS_FILE = 'users.json';

if (fs.existsSync(USERS_FILE)) {
  users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
} else {
  users = [{
    id: 1,
    name: " Даниил Даниилов",
    email: "Daniil@example.com",
    avatar: "default-avatar.png",
    password: "123456" 
  }];
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    const uploadDir = 'uploads/avatars/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function(req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'avatar-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, 
  fileFilter: function(req, file, cb) {
    const filetypes = /jpeg|jpg|png|gif/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    
    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Только изображения разрешены'));
  }
});

app.get('/api/user', (req, res) => {
  res.json(users[0] || null);
});

app.put('/api/user', (req, res) => {
  try {
    const { name, email } = req.body;
    
    if (users[0]) {
      users[0].name = name || users[0].name;
      users[0].email = email || users[0].email;
      
      fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
      res.json({ 
        success: true, 
        user: users[0],
        message: 'Данные обновлены успешно'
      });
    } else {
      res.status(404).json({ error: 'Пользователь не найден' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при обновлении данных' });
  }
});

app.post('/api/user/avatar', upload.single('avatar'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Файл не загружен' });
    }
    
    if (users[0]) {
      if (users[0].avatar !== 'default-avatar.png') {
        const oldAvatarPath = path.join(__dirname, 'uploads/avatars/', users[0].avatar);
        if (fs.existsSync(oldAvatarPath)) {
          fs.unlinkSync(oldAvatarPath);
        }
      }
      
      users[0].avatar = req.file.filename;
      fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
      
      res.json({ 
        success: true, 
        avatar: users[0].avatar,
        message: 'Аватар обновлен успешно'
      });
    } else {
      res.status(404).json({ error: 'Пользователь не найден' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при загрузке аватара' });
  }
});

app.delete('/api/user/avatar', (req, res) => {
  try {
    if (users[0] && users[0].avatar !== 'default-avatar.png') {
      const avatarPath = path.join(__dirname, 'uploads/avatars/', users[0].avatar);
      if (fs.existsSync(avatarPath)) {
        fs.unlinkSync(avatarPath);
      }
      
      users[0].avatar = 'default-avatar.png';
      fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
      
      res.json({ 
        success: true, 
        message: 'Аватар удален'
      });
    } else {
      res.status(400).json({ error: 'Невозможно удалить аватар' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Ошибка при удалении аватара' });
  }
});

app.post('/api/user/check-password', (req, res) => {
  const { password } = req.body;
  
  if (users[0] && users[0].password === password) {
    res.json({ valid: true });
  } else {
    res.json({ valid: false, error: 'Неверный пароль' });
  }
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
  console.log(`Загруженные файлы доступны по http://localhost:${PORT}/uploads/avatars/`);
});